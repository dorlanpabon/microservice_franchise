package com.pragma.franchise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FranchiseApplicationTests {

    @Test
    void contextLoads() { // default implementation ignored
    }

}
